/*---------------------------------------------------------------------------*  =========                 |
  \\      /  F ield         | OpenFOAM: The Open Source CFD Toolbox
   \\    /   O peration     | Website:  https://openfoam.org
    \\  /    A nd           | Copyright (C) YEAR OpenFOAM Foundation
     \\/     M anipulation  |
-------------------------------------------------------------------------------
License
    This file is part of OpenFOAM.

    OpenFOAM is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    OpenFOAM is distributed in the hope that it will be useful, but WITHOUT
    ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
    FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
    for more details.

    You should have received a copy of the GNU General Public License
    along with OpenFOAM.  If not, see <http://www.gnu.org/licenses/>.

\*---------------------------------------------------------------------------*/

#include "functionObjectTemplate.H"
#include "fvCFD.H"
#include "unitConversion.H"
#include "addToRunTimeSelectionTable.H"

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //

namespace Foam
{

// * * * * * * * * * * * * * * Static Data Members * * * * * * * * * * * * * //

defineTypeNameAndDebug(p_totalFunctionObject, 0);

addRemovableToRunTimeSelectionTable
(
    functionObject,
    p_totalFunctionObject,
    dictionary
);


// * * * * * * * * * * * * * * * Global Functions  * * * * * * * * * * * * * //

extern "C"
{
    // dynamicCode:
    // SHA1 = 4a4d26d64756f5caa1e5ba2974a016a0d592174c
    //
    // unique function name that can be checked if the correct library version
    // has been loaded
    void p_total_4a4d26d64756f5caa1e5ba2974a016a0d592174c(bool load)
    {
        if (load)
        {
            // code that can be explicitly executed after loading
        }
        else
        {
            // code that can be explicitly executed before unloading
        }
    }
}


// * * * * * * * * * * * * * * * Local Functions * * * * * * * * * * * * * * //

//{{{ begin localCode

//}}} end localCode


// * * * * * * * * * * * * * Private Member Functions  * * * * * * * * * * * //

const fvMesh& p_totalFunctionObject::mesh() const
{
    return refCast<const fvMesh>(obr_);
}


// * * * * * * * * * * * * * * * * Constructors  * * * * * * * * * * * * * * //

p_totalFunctionObject::p_totalFunctionObject
(
    const word& name,
    const Time& runTime,
    const dictionary& dict
)
:
    functionObjects::regionFunctionObject(name, runTime, dict)
{
    read(dict);
}


// * * * * * * * * * * * * * * * * Destructor  * * * * * * * * * * * * * * * //

p_totalFunctionObject::~p_totalFunctionObject()
{}


// * * * * * * * * * * * * * * * Member Functions  * * * * * * * * * * * * * //

bool p_totalFunctionObject::read(const dictionary& dict)
{
    if (false)
    {
        Info<<"read p_total sha1: 4a4d26d64756f5caa1e5ba2974a016a0d592174c\n";
    }

//{{{ begin code
    
//}}} end code

    return true;
}


bool p_totalFunctionObject::execute()
{
    if (false)
    {
        Info<<"execute p_total sha1: 4a4d26d64756f5caa1e5ba2974a016a0d592174c\n";
    }

//{{{ begin code
    
//}}} end code

    return true;
}


bool p_totalFunctionObject::write()
{
    if (false)
    {
        Info<<"write p_total sha1: 4a4d26d64756f5caa1e5ba2974a016a0d592174c\n";
    }

//{{{ begin code
    #line 68 "/home/the_batman_who_laughs/OpenFOAM/the_batman_who_laughs-8/run/Project_2/pitzDaily_PIMPLE_totalP_trial1/system/controlDict/functions/totalPressure"
const volVectorField& U = mesh().lookupObject<volVectorField>("U");
    		const volScalarField& p = mesh().lookupObject<volScalarField>("p");
    		
    		Info<< "Creating field p_total\n" << endl;
		volScalarField p_total
		(
    			IOobject
    			(
        			"p_total",
        			mesh().time().timeName(),                                    
        			U.mesh(),
        			IOobject::NO_READ,
        			IOobject::AUTO_WRITE
    			),
    			p
		);
    		
    		 		
    		p_total = p + (0.5*magSqr(U));
    		
    		p_total.write();
//}}} end code

    return true;
}


bool p_totalFunctionObject::end()
{
    if (false)
    {
        Info<<"end p_total sha1: 4a4d26d64756f5caa1e5ba2974a016a0d592174c\n";
    }

//{{{ begin code
    
//}}} end code

    return true;
}


// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //

} // End namespace Foam

// ************************************************************************* //

